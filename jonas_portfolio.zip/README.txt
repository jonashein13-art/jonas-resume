JONAS PORTFOLIO WEBSITE

Files:
- index.html: the complete responsive website (HTML, CSS and JavaScript in one file).

Preview:
1. Extract the ZIP file.
2. Open index.html in a browser.

Custom domain:
This website is ready to be hosted on a static hosting service such as GitHub Pages or Netlify.
After publishing, add your custom domain in the hosting provider's domain settings and update the
DNS records at your domain registrar using the exact values provided by that host.

Before publishing:
- Check that every experience statement is accurate.
- Add a contact link or social links if you want visitors to reach you.
- Replace any wording you would like to personalise.
